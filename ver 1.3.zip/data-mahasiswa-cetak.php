<center>
<table border=1 cellspacing=1 cellpading=5 width="100%" >
	<thead>
	<tr>			
		<th>No</th>
		<th>NIM</th>
		<th>Nama Mahasiswa</th>
		<th>Gender</th>
		<th>Nilai</th>
		<th>Tanggal Input</th>
		
	</tr>
	<tbody>
	<?php
	include 'koneksi.php';
	$tgl_awal  = $_GET['tgl_awal'];
	$tgl_akhir = $_GET['tgl_akhir'];
	$no = 0;
	if($_GET['tgl_awal']){
		$query  = mysqli_query($mysqli,"SELECT * FROM tb_mahasiswa 
		WHERE SUBSTR(waktu_input,1,10) BETWEEN '$tgl_awal' AND '$tgl_akhir'");
	}
	else{
		$query  = mysqli_query($mysqli,"SELECT * FROM tb_mahasiswa");
	}
	while($result = mysqli_fetch_array($query)){
		$no++;
?>		
	<tr>
		<td><?php echo $no;?></td>
		<td><?php echo $result['nim'];?></td>
		<td><?php echo $result['nama'];?></td>
		<td><?php echo $result['gender'];?></td>
		<td><?php echo $result['nilai'];?></td>
		<td><?php echo $result['waktu_input'];?></td>
		
	</tr>	
	
<?php }
?>

	
	</tbody>
</table>
</center>