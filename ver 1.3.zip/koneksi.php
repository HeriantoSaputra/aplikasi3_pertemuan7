<?php
$server 	= 'localhost';
$user		= 'root';
$database 	= 'db_mahasiswa';
$password 	= '';

$mysqli = mysqli_connect($server,$user,$password,$database);

if (!$mysqli) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
//else{echo "Koneksi berhasil";}

?>