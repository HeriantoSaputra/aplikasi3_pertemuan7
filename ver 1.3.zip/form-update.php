<?php 
include 'koneksi.php';
$id = $_GET['id'];
$query  = mysqli_query($mysqli,"SELECT * FROM tb_mahasiswa WHERE id='$id'");
	$result = mysqli_fetch_array($query);
//echo $id;
?>
<style>
    table{border-collapse:collapse;}
</style>
<center>
<h1>Form Update Data Nilai</h1>
<table border=1 width="500px">
<form method="get" action="update.php">
<input name='id' value='<?php echo $id;?>' hidden>
 <tr>   
    <td>Nama mahasiswa</td><td>  : </td><td><input name='nama' value="<?php echo $result['nama'];?>"></td>
</tr>
<tr>   
    <td>NIM</td><td>  : </td><td><input name='nim' value="<?php echo $result['nim'];?>"></td>
</tr>
<tr>   
    <td>Gender</td><td>  : </td><td>
        <select name="gender">
            <option value="<?php echo $result['gender'];?>"><?php echo $result['gender'];?></option>
            <option >Laki-laki</option>
            <option>Perempuan</option>
        </select>
    </td>
</tr>
<tr>   
    <td>Nilai</td><td>  : </td><td><input name='nilai' value="<?php echo $result['nilai'];?>"></td>
</tr>
<tr>
    <td colspan="3" align="center"><button> Simpan</button></td>
</tr>
</form>
</table>
</center>

