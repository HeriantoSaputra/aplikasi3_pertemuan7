<?php
include 'koneksi.php';

$id = $_GET['id'];
$query  = mysqli_query($mysqli,"INSERT INTO tb_mahasiswa (id) VALUES ('')");

header('Location:data-mahasiswa.php');
exit;
?>